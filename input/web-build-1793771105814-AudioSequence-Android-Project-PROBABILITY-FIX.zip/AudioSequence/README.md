# Audio Sequence – Android project

Version 0.6.0 corrects category probability behavior and playlist length generation.

## Playlist length and probability behavior
- Each playlist stores its own minimum and maximum track count.
- Defaults for existing and new playlists: minimum 4, maximum 48.
- The minimum is enforced before the Y → Z ending can occur; the maximum is a hard upper bound.
- No random target length forces the app to keep adding A tracks. Instead, category probabilities are applied at each eligible selection.
- Once the minimum can be met, Y becomes eligible as a weighted ending choice. A high Y probability therefore makes short playlists much more likely; a low Y probability allows more continuation tracks.
- Example: with A=1%, Y=99%, B=X=0%, and a minimum of 4, the expected common result is Starter → A → Y → Z. There remains a 1% chance of selecting another eligible continuation instead of Y at that decision.
- Track count includes Starter and the final Z. Allowed values: 4–999.

## B sequencing restriction
After a B track, the sequence must contain A → B → A before X or Y can become eligible. X and Y cannot immediately follow either B in that pair.

The project retains playlist management, category looping controls, audio playback, and subtitle/lyric functionality.

## Build
Open the project in Android Studio or use AndroidForge. Build the `debug` variant to produce an installable test APK.


## Version 0.6.0 – probability and playlist length correction

Category weights are now applied at each eligible decision point. Once the configured minimum length can be satisfied, Y becomes eligible as a weighted terminal choice and ends the sequence with Z. A high Y weight therefore makes short playlists much more likely; for example, A=1%, Y=99%, with B=X=0% and a 4-track minimum should normally produce Starter → A → Y → Z. The maximum is a hard upper bound, not a randomly selected target that forces A tracks to continue. The B rule is enforced as B → A → B → A before X or Y can follow.
