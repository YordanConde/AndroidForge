package com.example.audiosequence

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

private val categories = listOf("Starter", "A", "B", "X", "Y", "Z")
private data class AudioFile(val id: String, val name: String, val uri: String, val category: String, val lrc: String? = null)
private data class QueueEntry(val file: AudioFile, val category: String)
private data class PlaylistData(val files: List<AudioFile>, val probabilities: Map<String, String>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AudioSequenceApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AudioSequenceApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("audio_sequence", 0) }
    val savedPlaylists = remember { loadPlaylists(prefs.getString("playlists", "") ?: "") }
    val playlistNames = remember { mutableStateListOf<String>().apply { addAll(savedPlaylists.keys) } }
    if (playlistNames.isEmpty()) playlistNames.add("My playlist")
    var activePlaylist by remember { mutableStateOf(prefs.getString("active_playlist", playlistNames.first()) ?: playlistNames.first()) }
    if (activePlaylist !in playlistNames) activePlaylist = playlistNames.first()
    val initialData = savedPlaylists[activePlaylist]
    val files = remember { mutableStateListOf<AudioFile>().apply {
        addAll(initialData?.files ?: loadFiles(prefs.getString("files", "[]") ?: "[]"))
    } }
    val probs = remember { mutableStateMapOf<String, String>().apply {
        putAll(initialData?.probabilities ?: mapOf("A" to "65", "B" to "5", "X" to "5", "Y" to "25"))
    } }
    var selectedCategory by remember { mutableStateOf("Starter") }
    var selectedSubtitleId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("Add your audio files to begin.") }
    var playing by remember { mutableStateOf(false) }
    var currentTitle by remember { mutableStateOf("Nothing playing") }
    var currentLyrics by remember { mutableStateOf("") }
    var currentLine by remember { mutableStateOf("") }
    var queueNames by remember { mutableStateOf<List<String>>(emptyList()) }
    var queue by remember { mutableStateOf<List<QueueEntry>>(emptyList()) }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var playlistMenuExpanded by remember { mutableStateOf(false) }
    var showNewPlaylistDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var descriptionExpanded by remember { mutableStateOf(false) }
    var orderExpanded by remember { mutableStateOf(false) }

    fun persistActive() {
        val all = loadPlaylists(prefs.getString("playlists", "") ?: "").toMutableMap()
        all[activePlaylist] = PlaylistData(files.toList(), probs.toMap())
        prefs.edit().putString("playlists", savePlaylists(all)).putString("active_playlist", activePlaylist).apply()
        // Keep the legacy key updated for backward compatibility.
        prefs.edit().putString("files", saveFiles(files)).apply()
    }
    fun save() = persistActive()
    fun switchPlaylist(name: String) {
        if (name == activePlaylist) return
        persistActive()
        player?.stop(); player?.release(); player = null
        playing = false
        queue = emptyList(); queueNames = emptyList()
        currentTitle = "Nothing playing"; currentLine = ""; currentLyrics = ""
        val data = loadPlaylists(prefs.getString("playlists", "") ?: "")[name]
        files.clear(); files.addAll(data?.files ?: emptyList())
        probs.clear(); probs.putAll(data?.probabilities ?: mapOf("A" to "65", "B" to "5", "X" to "5", "Y" to "25"))
        activePlaylist = name
        prefs.edit().putString("active_playlist", name).apply()
        message = "Selected playlist: $name"
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val chosenUris = if (selectedCategory == "Starter") uris.take(1) else uris
            chosenUris.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val name = displayName(context, uri)
                if (selectedCategory == "Starter") files.removeAll { it.category == "Starter" }
                files.add(AudioFile(java.util.UUID.randomUUID().toString(), name, uri.toString(), selectedCategory))
            }
            save(); message = "Added ${chosenUris.size} file(s) to $selectedCategory."
        }
    }
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && selectedSubtitleId != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val text = try { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } } catch (_: Exception) { null }
            val index = files.indexOfFirst { it.id == selectedSubtitleId }
            if (index >= 0 && text != null) { files[index] = files[index].copy(lrc = text); save(); message = "Lyrics attached to ${files[index].name}." }
        }
        selectedSubtitleId = null
    }

    DisposableEffect(player) { val activePlayer = player; onDispose { activePlayer?.release() } }
    LaunchedEffect(player, playing) {
        while (player != null && playing) {
            val p = player ?: break
            val entry = queue.getOrNull(p.currentMediaItemIndex)
            if (entry != null) { currentTitle = entry.file.name; currentLyrics = entry.file.lrc ?: ""; currentLine = lyricAt(currentLyrics, p.currentPosition) }
            delay(100)
        }
    }

    if (showNewPlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showNewPlaylistDialog = false; newPlaylistName = "" },
            title = { Text("Create playlist") },
            text = { OutlinedTextField(value = newPlaylistName, onValueChange = { newPlaylistName = it }, label = { Text("Playlist name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                val name = newPlaylistName.trim()
                if (name.isNotEmpty() && name !in playlistNames) {
                    persistActive()
                    playlistNames.add(name)
                    switchPlaylist(name)
                    persistActive()
                } else if (name in playlistNames) message = "A playlist with that name already exists."
                showNewPlaylistDialog = false; newPlaylistName = ""
            }) { Text("Create") } },
            dismissButton = { TextButton(onClick = { showNewPlaylistDialog = false; newPlaylistName = "" }) { Text("Cancel") } }
        )
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Audio Sequence") }) }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp)) {
                item {
                    Text("Playlist", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.weight(1f)) {
                            OutlinedButton(onClick = { playlistMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("$activePlaylist  ▾") }
                            DropdownMenu(expanded = playlistMenuExpanded, onDismissRequest = { playlistMenuExpanded = false }) {
                                playlistNames.forEach { name -> DropdownMenuItem(text = { Text(name) }, onClick = { playlistMenuExpanded = false; switchPlaylist(name) }) }
                            }
                        }
                        Button(onClick = { showNewPlaylistDialog = true }) { Text("+ New") }
                    }
                    Text("Each playlist has its own audio files and probability settings.", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Card(onClick = { descriptionExpanded = !descriptionExpanded }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("How the playback rules work", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                Text(if (descriptionExpanded) "▲" else "▼")
                            }
                            if (descriptionExpanded) {
                                Spacer(Modifier.height(8.dp))
                                Text("Starter plays first. A can follow. B can only follow A and B files cannot play consecutively. X requires a previous A and forces Y immediately after it. Y can also occur independently and always forces Z. Z ends playback. Individual files repeat only after every file in their category has played once. After a B, X and Y remain blocked until another B has occurred (with an A between the two B files).", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                item {
                    Text("1. Add audio files", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Add files to the selected playlist. Starter accepts one file; the other categories accept batches.", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }) { Text("Add $selectedCategory ▾") }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                categories.forEach { cat -> DropdownMenuItem(text = { Text(cat) }, onClick = { selectedCategory = cat; expanded = false }) }
                            }
                        }
                        Button(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text(if (selectedCategory == "Starter") "Choose Starter" else "Add files") }
                    }
                    Text("${files.size} audio file(s) in $activePlaylist", style = MaterialTheme.typography.labelLarge)
                }
                items(categories) { cat ->
                    val group = files.filter { it.category == cat }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("$cat  (${group.size})", fontWeight = FontWeight.Bold)
                            if (group.isEmpty()) Text("No files yet", style = MaterialTheme.typography.bodySmall)
                            group.forEach { file ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(file.name + if (file.lrc != null) "  • lyrics" else "", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                    TextButton(onClick = { selectedSubtitleId = file.id; subtitlePicker.launch(arrayOf("text/*", "application/octet-stream")) }) { Text("LRC") }
                                    TextButton(onClick = { files.remove(file); save() }) { Text("Remove") }
                                }
                            }
                        }
                    }
                }
                item {
                    Text("2. Selection probabilities", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Enter relative chances for A, B, X and Y. They must total 100%. Ineligible categories are excluded and the remaining chances are re-normalized.", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("A", "B", "X", "Y").forEach { cat -> OutlinedTextField(value = probs[cat] ?: "0", onValueChange = { v -> if (v.length <= 3 && v.all(Char::isDigit)) { probs[cat] = v; save() } }, label = { Text(cat) }, modifier = Modifier.weight(1f), singleLine = true) }
                    }
                    val total = listOf("A", "B", "X", "Y").sumOf { probs[it]?.toIntOrNull() ?: 0 }
                    Text("Total: $total%", color = if (total == 100) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
                item {
                    Text("3. Playback", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Button(onClick = {
                        val starter = files.count { it.category == "Starter" }; val a = files.count { it.category == "A" }; val y = files.count { it.category == "Y" }; val z = files.count { it.category == "Z" }
                        val values = listOf("A", "B", "X", "Y").associateWith { probs[it]?.toIntOrNull() ?: -1 }; val sum = values.values.sum()
                        if (starter != 1 || a == 0 || y == 0 || z == 0) message = "Add exactly one Starter, at least one A, one Y and one Z file."
                        else if (values.values.any { it !in 0..100 } || sum != 100 || values["A"] == 0 || values["Y"] == 0) message = "Probabilities must be 0–100, total 100, and A and Y must be above 0%."
                        else try {
                            val generated = generateQueue(files.toList(), values)
                            queue = generated; queueNames = generated.mapIndexed { i, e -> "${i + 1}. [${e.category}] ${e.file.name}" }
                            player?.release()
                            val p = ExoPlayer.Builder(context).build(); player = p
                            p.setMediaItems(generated.map { MediaItem.fromUri(Uri.parse(it.file.uri)) }); p.prepare(); p.playWhenReady = true
                            p.addListener(object : Player.Listener {
                                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                                override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_ENDED) { playing = false; currentTitle = "Playlist finished"; currentLine = ""; message = "Playback complete." } }
                                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { val entry = generated.getOrNull(p.currentMediaItemIndex); currentTitle = entry?.file?.name ?: "Nothing playing"; currentLyrics = entry?.file?.lrc ?: ""; currentLine = lyricAt(currentLyrics, p.currentPosition) }
                            })
                            message = "Playlist generated: ${generated.size} tracks. Playback started."
                        } catch (e: Exception) { message = "Couldn't generate playlist: ${e.message ?: "check your files and rules"}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Generate & play playlist") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { player?.pause(); playing = false }) { Text("Pause") }
                        OutlinedButton(onClick = { player?.play(); playing = true }) { Text("Resume") }
                        OutlinedButton(onClick = { player?.seekToNextMediaItem() }) { Text("Skip") }
                        OutlinedButton(onClick = { player?.stop(); playing = false; currentTitle = "Stopped" }) { Text("Stop") }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("NOW PLAYING", style = MaterialTheme.typography.labelMedium)
                            Text(currentTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text(currentLine.ifBlank { if (currentLyrics.isBlank()) "No synchronized lyrics attached" else "…" }, style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                }
                item {
                    Card(onClick = { orderExpanded = !orderExpanded }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("Generated order & playback details", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                Text(if (orderExpanded) "▲" else "▼")
                            }
                            if (orderExpanded) {
                                Spacer(Modifier.height(8.dp))
                                Text(message, style = MaterialTheme.typography.bodySmall)
                                Text("Generated order (${queueNames.size} tracks)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                if (queueNames.isEmpty()) Text("No generated order yet.", style = MaterialTheme.typography.bodySmall)
                                queueNames.forEach { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun generateQueue(all: List<AudioFile>, weights: Map<String, Int>): List<QueueEntry> {
    val pools = listOf("A", "B", "X", "Y").associateWith { cat -> all.filter { it.category == cat } }
    require(pools["A"].orEmpty().isNotEmpty() && pools["Y"].orEmpty().isNotEmpty() && all.any { it.category == "Z" })
    val used = mutableMapOf<String, MutableSet<String>>()
    val previousLast = mutableMapOf<String, String>()
    val result = mutableListOf<QueueEntry>()
    result += QueueEntry(all.single { it.category == "Starter" }, "Starter")
    var previousCategory = "Starter"
    var hasPlayedA = false
    var mustPlayAnotherB = false
    var guard = 0

    fun draw(cat: String): AudioFile {
        val pool = pools[cat].orEmpty(); require(pool.isNotEmpty()) { "Category $cat has no files" }
        var played = used.getOrPut(cat) { mutableSetOf() }
        if (played.size == pool.size) played = mutableSetOf<String>().also { used[cat] = it }
        val available = pool.filter { it.id !in played }.toMutableList(); available.shuffle()
        val last = previousLast[cat]
        if (available.size > 1 && available.first().id == last) { val swap = available.indexOfFirst { it.id != last }; val temp = available[0]; available[0] = available[swap]; available[swap] = temp }
        val chosen = available.first(); played.add(chosen.id); previousLast[cat] = chosen.id
        return chosen
    }

    while (true) {
        guard++; require(guard < 10000) { "Unable to reach Y/Z ending; check category probabilities" }
        val eligible = mutableListOf<String>()
        if (pools["A"].orEmpty().isNotEmpty()) eligible += "A"
        if (previousCategory == "A" && pools["B"].orEmpty().isNotEmpty()) eligible += "B"
        if (hasPlayedA && !mustPlayAnotherB && pools["X"].orEmpty().isNotEmpty()) eligible += "X"
        if (hasPlayedA && !mustPlayAnotherB && pools["Y"].orEmpty().isNotEmpty()) eligible += "Y"
        val weighted = eligible.map { it to (weights[it] ?: 0).coerceAtLeast(0) }.filter { it.second > 0 }
        require(weighted.isNotEmpty()) { if (mustPlayAnotherB) "After B, the rules require another B (with an A between). Increase B's probability above 0%." else "No eligible category has a positive probability" }
        val total = weighted.sumOf { it.second }; var roll = Random.nextInt(total); var chosenCategory = weighted.last().first
        for ((cat, weight) in weighted) { if (roll < weight) { chosenCategory = cat; break }; roll -= weight }
        val chosen = draw(chosenCategory); result += QueueEntry(chosen, chosenCategory)
        if (chosenCategory == "A") hasPlayedA = true
        if (chosenCategory == "B") mustPlayAnotherB = !mustPlayAnotherB
        previousCategory = chosenCategory
        if (chosenCategory == "X" || chosenCategory == "Y") {
            if (chosenCategory == "X") result += QueueEntry(draw("Y"), "Y")
            result += QueueEntry(all.filter { it.category == "Z" }.random(), "Z")
            break
        }
    }
    return result
}

private fun lyricAt(lrc: String, positionMs: Long): String {
    if (lrc.isBlank()) return ""
    val entries = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\](.*)").findAll(lrc).mapNotNull { m ->
        val min = m.groupValues[1].toLongOrNull() ?: return@mapNotNull null; val sec = m.groupValues[2].toLongOrNull() ?: return@mapNotNull null
        val fracRaw = m.groupValues[3]; val frac = when (fracRaw.length) { 1 -> fracRaw.toLong() * 100; 2 -> fracRaw.toLong() * 10; 3 -> fracRaw.toLong(); else -> 0L }
        (min * 60000 + sec * 1000 + frac) to m.groupValues[4].trim()
    }.sortedBy { it.first }.toList()
    return entries.lastOrNull { it.first <= positionMs }?.second ?: ""
}

private fun displayName(context: android.content.Context, uri: Uri): String {
    var name = uri.lastPathSegment ?: "Audio"
    context.contentResolver.query(uri, null, null, null, null)?.use { c -> val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name }
    return name
}

private fun saveFiles(files: List<AudioFile>): String = JSONArray().apply { files.forEach { f -> put(JSONObject().put("id", f.id).put("name", f.name).put("uri", f.uri).put("category", f.category).put("lrc", f.lrc)) } }.toString()
private fun loadFiles(json: String): List<AudioFile> = try { val arr = JSONArray(json); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); AudioFile(o.getString("id"), o.getString("name"), o.getString("uri"), o.getString("category"), if (o.isNull("lrc")) null else o.getString("lrc")) } } catch (_: Exception) { emptyList() }

private fun savePlaylists(playlists: Map<String, PlaylistData>): String = JSONObject().apply {
    playlists.forEach { (name, data) -> put(name, JSONObject().put("files", saveFiles(data.files)).put("probabilities", JSONObject(data.probabilities))) }
}.toString()
private fun loadPlaylists(json: String): Map<String, PlaylistData> = try {
    if (json.isBlank()) emptyMap() else {
        val root = JSONObject(json); buildMap {
            val keys = root.keys(); while (keys.hasNext()) { val name = keys.next(); val item = root.getJSONObject(name); val p = item.optJSONObject("probabilities") ?: JSONObject(); put(name, PlaylistData(loadFiles(item.optString("files", "[]")), mapOf("A" to p.optString("A", "65"), "B" to p.optString("B", "5"), "X" to p.optString("X", "5"), "Y" to p.optString("Y", "25")))) }
        }
    }
} catch (_: Exception) { emptyMap() }
