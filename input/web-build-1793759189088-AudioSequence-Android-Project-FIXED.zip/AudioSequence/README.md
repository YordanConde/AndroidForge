# Audio Sequence (Android prototype)

A native Android prototype for rule-based randomized audio playlists. The project is written in Kotlin with Jetpack Compose and AndroidX Media3.

## Current prototype features

- Guided category-based import: Starter, A, B, X, Y and Z.
- Starter accepts one file; the other categories accept multiple files.
- Local persistence of imported audio references and attached LRC text.
- Manually configurable A/B/X/Y selection weights (must total 100%).
- Rule engine:
  - Starter is first.
  - A is always eligible after Starter.
  - B is eligible only immediately after A, so B-B cannot occur.
  - X and Y are unavailable until at least one A has played.
  - X forces an immediate Y, and Y always forces Z.
  - Y can also be selected independently of X.
  - Z is terminal; the generated playlist ends after Z.
- Each category has its own no-repeat cycle. A file becomes eligible again only after all files in its category have been used. The cycle resets only when another file from that category is actually needed. The first file in a new cycle is kept different from the previous cycle's last file when the category has at least two files.
- LRC lyric import and current-line display.
- The full queue is generated before playback and handed to Media3 as one playlist to support gapless transitions where the source encodings/device decoder allow it.

## Build

Open this folder (`AudioSequence`) in a recent Android Studio version with Android SDK Platform 35 installed. Let Android Studio sync the Gradle project, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is normally created at:

`app/build/outputs/apk/debug/app-debug.apk`

The current execution environment does not contain the Android SDK or Gradle, so an APK could not be compiled or device-tested here. This is the Android Studio project/source, not a compiled APK.

## Important prototype limitations / next development pass

- Playback is currently foreground/UI-bound; a foreground media service, notification controls, audio focus handling and lock-screen controls should be added before everyday use.
- Gapless behavior depends on audio format/codec compatibility and Android device decoders. It should be tested on the target phone with the actual files. This version does not crossfade.
- The playlist is generated as a finite queue before playback. The rule engine uses weighted random selection and ends when Y is selected (or forced by X), followed by one random Z file.
- Playlist naming, multiple saved playlists, editing/reordering, richer subtitle styling, and validation previews are planned follow-ups.
- This is an early prototype. Test with copies of audio files before relying on it for important playback.
