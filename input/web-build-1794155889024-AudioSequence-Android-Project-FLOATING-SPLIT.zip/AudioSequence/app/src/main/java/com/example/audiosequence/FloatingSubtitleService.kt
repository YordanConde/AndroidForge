package com.example.audiosequence

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/** Movable, freely resizable subtitle overlay. */
class FloatingSubtitleService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private var subtitle: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val prefs by lazy { getSharedPreferences("audio_sequence", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (root == null) showOverlay() else refreshText()
        return START_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = FrameLayout(this).apply { setBackgroundColor(Color.argb(225, 12, 12, 12)) }
        val text = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(resolveColor(prefs.getString("subtitle_color", "White")))
            textSize = prefs.getFloat("subtitle_size", 36f)
            text = prefs.getString("overlay_line", "").orEmpty().ifBlank { "…" }
            setPadding(12, 28, 12, 28)
        }
        subtitle = text
        box.addView(text, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val close = TextView(this).apply {
            this.text = "×"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(180, 80, 20, 20))
            setOnClickListener { stopSelf() }
        }
        box.addView(close, FrameLayout.LayoutParams(42, 36, Gravity.TOP or Gravity.END))

        val dragBar = TextView(this).apply {
            this.text = "⠿  MOVE"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 0, 8, 0)
            setBackgroundColor(Color.argb(150, 50, 50, 50))
        }
        box.addView(dragBar, FrameLayout.LayoutParams(90, 28, Gravity.TOP or Gravity.START))

        val resize = TextView(this).apply {
            this.text = "◢"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(180, 50, 50, 50))
        }
        box.addView(resize, FrameLayout.LayoutParams(38, 38, Gravity.BOTTOM or Gravity.END))

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val lp = WindowManager.LayoutParams(420, 190, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 180 }
        params = lp
        dragBar.setOnTouchListener(MoveResizeTouch(lp, false))
        resize.setOnTouchListener(MoveResizeTouch(lp, true))
        root = box
        wm.addView(box, lp)
        startRefreshLoop()
    }

    private inner class MoveResizeTouch(private val lp: WindowManager.LayoutParams, private val resizing: Boolean) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f
        private var startX = 0; private var startY = 0; private var startW = 0; private var startH = 0
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y; startW = lp.width; startH = lp.height
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (resizing) { lp.width = (startW + dx).coerceAtLeast(120); lp.height = (startH + dy).coerceAtLeast(80) }
                    else { lp.x = startX + dx; lp.y = startY + dy }
                    try { root?.let { wm.updateViewLayout(it, lp) } } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return false
        }
    }

    private fun startRefreshLoop() {
        val handler = android.os.Handler(mainLooper)
        val task = object : Runnable {
            override fun run() {
                if (root == null) return
                refreshText()
                handler.postDelayed(this, 120)
            }
        }
        handler.post(task)
    }

    private fun refreshText() {
        val line = prefs.getString("overlay_line", "").orEmpty()
        subtitle?.text = line.ifBlank { "…" }
        subtitle?.textSize = prefs.getFloat("subtitle_size", 36f)
        subtitle?.setTextColor(resolveColor(prefs.getString("subtitle_color", "White")))
    }

    private fun resolveColor(name: String?): Int = when (name) {
        "Yellow" -> Color.YELLOW; "Cyan" -> Color.CYAN; "Green" -> Color.GREEN
        "Pink" -> Color.rgb(255, 128, 171); "Red" -> Color.rgb(255, 82, 82); else -> Color.WHITE
    }

    override fun onDestroy() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; subtitle = null
        super.onDestroy()
    }
}
