package com.example.audiosequence

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.ImageButton
import android.content.Context
import android.app.Service
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

private val categories = listOf("Starter", "A", "B", "X", "Y", "Z")
private data class AudioFile(val id: String, val name: String, val uri: String, val category: String, val lrc: String? = null)
private data class QueueEntry(val file: AudioFile, val category: String)
private data class PlaylistData(val files: List<AudioFile>, val probabilities: Map<String, String>, val looping: Map<String, Boolean> = mapOf("A" to true, "B" to true, "X" to true, "Y" to true), val minLength: Int = 4, val maxLength: Int = 48, val surpriseB: Boolean = false, val bFallbackMode: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AudioSequenceApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AudioSequenceApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("audio_sequence", 0) }
    val savedPlaylists = remember { loadPlaylists(prefs.getString("playlists", "") ?: "") }
    val playlistNames = remember { mutableStateListOf<String>().apply { addAll(savedPlaylists.keys) } }
    if (playlistNames.isEmpty()) playlistNames.add("My playlist")
    var activePlaylist by remember { mutableStateOf(prefs.getString("active_playlist", playlistNames.first()) ?: playlistNames.first()) }
    if (activePlaylist !in playlistNames) activePlaylist = playlistNames.first()
    val initialData = savedPlaylists[activePlaylist]
    val files = remember { mutableStateListOf<AudioFile>().apply {
        addAll(initialData?.files ?: loadFiles(prefs.getString("files", "[]") ?: "[]"))
    } }
    val probs = remember { mutableStateMapOf<String, String>().apply {
        putAll(initialData?.probabilities ?: mapOf("A" to "65", "B" to "5", "X" to "5", "Y" to "25"))
    } }
    val looping = remember { mutableStateMapOf<String, Boolean>().apply { putAll(initialData?.looping ?: defaultLooping()) } }
    var minLengthText by remember { mutableStateOf((initialData?.minLength ?: 4).toString()) }
    var maxLengthText by remember { mutableStateOf((initialData?.maxLength ?: 48).toString()) }
    var surpriseB by remember { mutableStateOf(initialData?.surpriseB ?: false) }
    var bFallbackMode by remember { mutableStateOf(initialData?.bFallbackMode ?: false) }
    var selectedCategory by remember { mutableStateOf("Starter") }
    var selectedSubtitleId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("Add your audio files to begin.") }
    var playing by remember { mutableStateOf(false) }
    var currentTitle by remember { mutableStateOf("Nothing playing") }
    var currentLyrics by remember { mutableStateOf("") }
    var currentLine by remember { mutableStateOf("") }
    var showSubtitleFocus by remember { mutableStateOf(false) }
    var subtitleSize by remember { mutableFloatStateOf(prefs.getFloat("subtitle_size", 36f).coerceIn(20f, 80f)) }
    var subtitleColorName by remember { mutableStateOf(prefs.getString("subtitle_color", "White") ?: "White") }
    val subtitleColors = linkedMapOf("White" to Color.White, "Yellow" to Color.Yellow, "Cyan" to Color.Cyan, "Green" to Color.Green, "Pink" to Color(0xFFFF80AB), "Red" to Color(0xFFFF5252))
    var queueNames by remember { mutableStateOf<List<String>>(emptyList()) }
    var queue by remember { mutableStateOf<List<QueueEntry>>(emptyList()) }
    var totalDurationText by remember { mutableStateOf("—") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var playlistMenuExpanded by remember { mutableStateOf(false) }
    var showNewPlaylistDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var showRenamePlaylistDialog by remember { mutableStateOf(false) }
    var renamePlaylistName by remember { mutableStateOf("") }
    var showDeletePlaylistDialog by remember { mutableStateOf(false) }
    var descriptionExpanded by remember { mutableStateOf(false) }
    var orderExpanded by remember { mutableStateOf(false) }

    fun persistActive() {
        val all = loadPlaylists(prefs.getString("playlists", "") ?: "").toMutableMap()
        all[activePlaylist] = PlaylistData(files.toList(), probs.toMap(), looping.toMap(), minLengthText.toIntOrNull() ?: 4, maxLengthText.toIntOrNull() ?: 48, surpriseB, bFallbackMode)
        prefs.edit().putString("playlists", savePlaylists(all)).putString("active_playlist", activePlaylist).apply()
        // Keep the legacy key updated for backward compatibility.
        prefs.edit().putString("files", saveFiles(files)).apply()
    }
    fun save() = persistActive()
    fun switchPlaylist(name: String) {
        if (name == activePlaylist) return
        persistActive()
        player?.stop(); player?.release(); player = null
        playing = false
        queue = emptyList(); queueNames = emptyList()
        currentTitle = "Nothing playing"; currentLine = ""; currentLyrics = ""
        val data = loadPlaylists(prefs.getString("playlists", "") ?: "")[name]
        files.clear(); files.addAll(data?.files ?: emptyList())
        probs.clear(); probs.putAll(data?.probabilities ?: mapOf("A" to "65", "B" to "5", "X" to "5", "Y" to "25"))
        looping.clear(); looping.putAll(data?.looping ?: defaultLooping())
        minLengthText = (data?.minLength ?: 4).toString(); maxLengthText = (data?.maxLength ?: 48).toString()
        surpriseB = data?.surpriseB ?: false
        bFallbackMode = data?.bFallbackMode ?: false
        activePlaylist = name
        prefs.edit().putString("active_playlist", name).apply()
        message = "Selected playlist: $name"
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val chosenUris = if (selectedCategory == "Starter") uris.take(1) else uris
            chosenUris.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val name = displayName(context, uri)
                if (selectedCategory == "Starter") files.removeAll { it.category == "Starter" }
                files.add(AudioFile(java.util.UUID.randomUUID().toString(), name, uri.toString(), selectedCategory))
            }
            save(); message = "Added ${chosenUris.size} file(s) to $selectedCategory."
        }
    }
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && selectedSubtitleId != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val text = try { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } } catch (_: Exception) { null }
            val index = files.indexOfFirst { it.id == selectedSubtitleId }
            if (index >= 0 && text != null) { files[index] = files[index].copy(lrc = text); save(); message = "Lyrics attached to ${files[index].name}." }
        }
        selectedSubtitleId = null
    }

    if (showSubtitleFocus) {
        Dialog(onDismissRequest = { showSubtitleFocus = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
            Box(Modifier.fillMaxSize().background(Color.Black).padding(24.dp), contentAlignment = Alignment.Center) {
                Text(currentLine.ifBlank { "…" }, color = subtitleColors[subtitleColorName] ?: Color.White,
                    fontSize = subtitleSize.sp, textAlign = TextAlign.Center, lineHeight = (subtitleSize * 1.25f).sp,
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }

    LaunchedEffect(queue) {
        totalDurationText = if (queue.isEmpty()) "—" else "Calculating…"
        if (queue.isNotEmpty()) {
            val totalMs = withContext(Dispatchers.IO) { calculateQueueDuration(context, queue) }
            totalDurationText = if (totalMs > 0L) formatDuration(totalMs) else "Unavailable"
        }
    }

    DisposableEffect(player) { val activePlayer = player; onDispose { activePlayer?.release() } }
    LaunchedEffect(player, playing) {
        while (player != null && playing) {
            val p = player ?: break
            val entry = queue.getOrNull(p.currentMediaItemIndex)
            if (entry != null) { currentTitle = entry.file.name; currentLyrics = entry.file.lrc ?: ""; currentLine = lyricAt(currentLyrics, p.currentPosition); prefs.edit().putString("overlay_line", currentLine).apply() }
            delay(100)
        }
    }

    if (showRenamePlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showRenamePlaylistDialog = false },
            title = { Text("Rename playlist") },
            text = { OutlinedTextField(value = renamePlaylistName, onValueChange = { renamePlaylistName = it }, label = { Text("New playlist name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                val newName = renamePlaylistName.trim()
                when {
                    newName.isBlank() -> message = "Playlist name cannot be empty."
                    newName != activePlaylist && newName in playlistNames -> message = "A playlist with that name already exists."
                    newName == activePlaylist -> Unit
                    else -> {
                        persistActive()
                        val all = loadPlaylists(prefs.getString("playlists", "") ?: "").toMutableMap()
                        val data = all.remove(activePlaylist) ?: PlaylistData(files.toList(), probs.toMap(), looping.toMap(), minLengthText.toIntOrNull() ?: 4, maxLengthText.toIntOrNull() ?: 48)
                        all[newName] = data
                        playlistNames[playlistNames.indexOf(activePlaylist)] = newName
                        activePlaylist = newName
                        prefs.edit().putString("playlists", savePlaylists(all)).putString("active_playlist", newName).apply()
                        message = "Playlist renamed to $newName."
                    }
                }
                showRenamePlaylistDialog = false
            }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showRenamePlaylistDialog = false }) { Text("Cancel") } }
        )
    }

    if (showDeletePlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showDeletePlaylistDialog = false },
            title = { Text("Delete playlist?") },
            text = { Text(if (playlistNames.size <= 1) "You cannot delete the only playlist. Create another playlist first." else "Delete '$activePlaylist' and all its saved audio assignments and settings? This cannot be undone.") },
            confirmButton = { TextButton(enabled = playlistNames.size > 1, onClick = {
                if (playlistNames.size > 1) {
                    val all = loadPlaylists(prefs.getString("playlists", "") ?: "").toMutableMap()
                    all.remove(activePlaylist)
                    playlistNames.remove(activePlaylist)
                    val nextName = playlistNames.first()
                    val nextData = all[nextName] ?: PlaylistData(emptyList(), mapOf("A" to "65", "B" to "5", "X" to "5", "Y" to "25"), defaultLooping())
                    player?.stop(); player?.release(); player = null
                    playing = false; queue = emptyList(); queueNames = emptyList()
                    currentTitle = "Nothing playing"; currentLine = ""; currentLyrics = ""
                    files.clear(); files.addAll(nextData.files)
                    probs.clear(); probs.putAll(nextData.probabilities)
                    looping.clear(); looping.putAll(nextData.looping)
                    minLengthText = nextData.minLength.toString(); maxLengthText = nextData.maxLength.toString()
                    activePlaylist = nextName
                    prefs.edit().putString("playlists", savePlaylists(all)).putString("active_playlist", nextName).putString("files", saveFiles(files)).apply()
                    message = "Playlist deleted. Switched to $nextName."
                }
                showDeletePlaylistDialog = false
            }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { showDeletePlaylistDialog = false }) { Text("Cancel") } }
        )
    }

    if (showNewPlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showNewPlaylistDialog = false; newPlaylistName = "" },
            title = { Text("Create playlist") },
            text = { OutlinedTextField(value = newPlaylistName, onValueChange = { newPlaylistName = it }, label = { Text("Playlist name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                val name = newPlaylistName.trim()
                if (name.isNotEmpty() && name !in playlistNames) {
                    persistActive()
                    playlistNames.add(name)
                    switchPlaylist(name)
                    persistActive()
                } else if (name in playlistNames) message = "A playlist with that name already exists."
                showNewPlaylistDialog = false; newPlaylistName = ""
            }) { Text("Create") } },
            dismissButton = { TextButton(onClick = { showNewPlaylistDialog = false; newPlaylistName = "" }) { Text("Cancel") } }
        )
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Audio Sequence") }) }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp)) {
                item {
                    Text("Playlist", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.weight(1f)) {
                            OutlinedButton(onClick = { playlistMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("$activePlaylist  ▾", maxLines = 1) }
                            DropdownMenu(expanded = playlistMenuExpanded, onDismissRequest = { playlistMenuExpanded = false }) {
                                playlistNames.forEach { name -> DropdownMenuItem(text = { Text(name) }, onClick = { playlistMenuExpanded = false; switchPlaylist(name) }) }
                            }
                        }
                        Button(onClick = { showNewPlaylistDialog = true }) { Text("+ New") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { renamePlaylistName = activePlaylist; showRenamePlaylistDialog = true }, modifier = Modifier.weight(1f)) { Text("Rename") }
                        OutlinedButton(onClick = { showDeletePlaylistDialog = true }, enabled = playlistNames.size > 1, modifier = Modifier.weight(1f)) { Text("Delete") }
                    }
                    Text("Each playlist has its own audio files and probability settings.", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Card(onClick = { descriptionExpanded = !descriptionExpanded }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("How the playback rules work", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                Text(if (descriptionExpanded) "▲" else "▼")
                            }
                            if (descriptionExpanded) {
                                Spacer(Modifier.height(8.dp))
                                Text("Starter plays first. A is the main category. B can only follow A, and every B is followed by A. X requires a previous A and cannot immediately follow B or another X. Y can occur independently and always forces Z, which ends playback. With B fallback sequence enabled, A is followed by X or Y when selected; otherwise B is inserted. After X, Y gets the next opportunity; if it is not selected, B is inserted before returning to A. With the option disabled, the normal weighted category rules apply. Each category has an independent looping switch. Surprise B boosts B's normal-mode weight after several A tracks; it does not alter the fallback sequence.", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                item {
                    Text("1. Add audio files", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Add files to the selected playlist. Starter accepts one file; the other categories accept batches.", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }) { Text("Add $selectedCategory ▾") }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                categories.forEach { cat -> DropdownMenuItem(text = { Text(cat) }, onClick = { selectedCategory = cat; expanded = false }) }
                            }
                        }
                        Button(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text(if (selectedCategory == "Starter") "Choose Starter" else "Add files") }
                    }
                    Text("${files.size} audio file(s) in $activePlaylist", style = MaterialTheme.typography.labelLarge)
                }
                items(categories) { cat ->
                    val group = files.filter { it.category == cat }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("$cat  (${group.size})", fontWeight = FontWeight.Bold)
                            if (group.isEmpty()) Text("No files yet", style = MaterialTheme.typography.bodySmall)
                            group.forEach { file ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(file.name + if (file.lrc != null) "  • subtitles" else "", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                    TextButton(onClick = { selectedSubtitleId = file.id; subtitlePicker.launch(arrayOf("application/x-subrip", "text/plain", "text/*", "application/octet-stream")) }) { Text("Subtitles") }
                                    TextButton(onClick = { files.remove(file); save() }) { Text("Remove") }
                                }
                            }
                        }
                    }
                }
                item {
                    Text("2. Category looping", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Choose whether A and B can start a new cycle after every file in that category has played once. Turn looping off to use each file at most once in the generated sequence. X can appear at most once per generated playlist. Y ends the playlist with Z.", style = MaterialTheme.typography.bodyMedium)
                    listOf("A", "B").forEach { cat ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Loop $cat", fontWeight = FontWeight.Medium)
                                Text(if (looping[cat] != false) "Repeat the category after its cycle is complete" else "Do not repeat files from this category", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = looping[cat] != false, onCheckedChange = { looping[cat] = it; save() })
                        }
                    }
                }
                item {
                    Text("3. Selection probabilities", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Enter relative chances for A, B, X and Y. They must total 100%. Ineligible categories are excluded and the remaining chances are re-normalized.", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("A", "B", "X", "Y").forEach { cat -> OutlinedTextField(value = probs[cat] ?: "0", onValueChange = { v -> if (v.length <= 3 && v.all(Char::isDigit)) { probs[cat] = v; save() } }, label = { Text(cat) }, modifier = Modifier.weight(1f), singleLine = true) }
                    }
                    val total = listOf("A", "B", "X", "Y").sumOf { probs[it]?.toIntOrNull() ?: 0 }
                    Text("Total: $total%", color = if (total == 100) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Surprise B", fontWeight = FontWeight.Medium)
                            Text("Gradually boosts B's selection weight after several A tracks. It never guarantees a B.", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = surpriseB, onCheckedChange = { surpriseB = it; save() })
                    }
                    if (surpriseB) {
                        Text("After 0–2 A tracks: ×1.00  •  3: ×1.15  •  4: ×1.40  •  5: ×1.80  •  6: ×2.50  •  7: ×3.80  •  8+: ×6.00. The multiplier applies to B's configured weight. Set B above 0% for Surprise B to have an effect.", style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("B fallback sequence", fontWeight = FontWeight.Medium)
                            Text("After A, choose X or Y if selected by their relative weights; otherwise B is inserted. After X, Y gets the next chance; if Y is not selected, B is inserted. Every B is followed by A.", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = bFallbackMode, onCheckedChange = { bFallbackMode = it; save() })
                    }
                }
                item {
                    Text("4. Playlist length range", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("The generated playlist can be any length within these limits. Category probabilities influence when the sequence ends: once the minimum length is reached, Y becomes eligible according to its probability and ends the playlist with Z. A higher Y probability therefore usually produces shorter playlists; a lower Y probability usually produces longer ones. Length includes Starter and the final Z track.", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = minLengthText, onValueChange = { v -> if (v.length <= 4 && v.all(Char::isDigit)) { minLengthText = v; save() } }, label = { Text("Minimum tracks") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = maxLengthText, onValueChange = { v -> if (v.length <= 4 && v.all(Char::isDigit)) { maxLengthText = v; save() } }, label = { Text("Maximum tracks") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Text("Allowed range: 4–999 tracks. Minimum must not exceed maximum.", style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Text("5. Playback", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Button(onClick = {
                        val starter = files.count { it.category == "Starter" }; val a = files.count { it.category == "A" }; val y = files.count { it.category == "Y" }; val z = files.count { it.category == "Z" }
                        val values = listOf("A", "B", "X", "Y").associateWith { probs[it]?.toIntOrNull() ?: -1 }; val sum = values.values.sum()
                        val minLen = minLengthText.toIntOrNull() ?: 0; val maxLen = maxLengthText.toIntOrNull() ?: 0
                        if (starter != 1 || a == 0 || y == 0 || z == 0) message = "Add exactly one Starter, at least one A, one Y and one Z file."
                        else if (minLen !in 4..999 || maxLen !in 4..999 || minLen > maxLen) message = "Playlist length must be between 4 and 999 tracks, and minimum cannot exceed maximum."
                        else if (values.values.any { it !in 0..100 } || sum != 100 || values["A"] == 0 || values["Y"] == 0) message = "Probabilities must be 0–100, total 100, and A and Y must be above 0%."
                        else try {
                            val generated = generateQueue(files.toList(), values, looping.toMap(), minLen, maxLen, surpriseB, bFallbackMode)
                            queue = generated; queueNames = generated.mapIndexed { i, e -> "${i + 1}. [${e.category}] ${e.file.name}" }
                            player?.release()
                            val p = ExoPlayer.Builder(context).build(); player = p
                            p.setMediaItems(generated.map { MediaItem.fromUri(Uri.parse(it.file.uri)) }); p.prepare(); p.playWhenReady = true
                            p.addListener(object : Player.Listener {
                                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                                override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_ENDED) { playing = false; currentTitle = "Playlist finished"; currentLine = ""; message = "Playback complete." } }
                                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { val entry = generated.getOrNull(p.currentMediaItemIndex); currentTitle = entry?.file?.name ?: "Nothing playing"; currentLyrics = entry?.file?.lrc ?: ""; currentLine = lyricAt(currentLyrics, p.currentPosition) }
                            })
                            message = "Playlist generated: ${generated.size} tracks. Playback started."
                        } catch (e: Exception) { message = "Couldn't generate playlist: ${e.message ?: "check your files and rules"}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Generate & play playlist") }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { player?.pause(); playing = false }, modifier = Modifier.weight(1f)) { Text("Pause") }
                        OutlinedButton(onClick = { player?.play(); playing = true }, modifier = Modifier.weight(1f)) { Text("Resume") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { player?.seekToNextMediaItem() }, modifier = Modifier.weight(1f)) { Text("Skip track") }
                        OutlinedButton(onClick = { player?.stop(); playing = false; currentTitle = "Stopped" }, modifier = Modifier.weight(1f)) { Text("Stop playback") }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("NOW PLAYING", style = MaterialTheme.typography.labelMedium)
                            Text(currentTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text(currentLine.ifBlank { if (currentLyrics.isBlank()) "No synchronized lyrics attached" else "…" },
                                style = MaterialTheme.typography.headlineSmall, color = subtitleColors[subtitleColorName] ?: Color.White)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { showSubtitleFocus = true }, modifier = Modifier.fillMaxWidth()) { Text("Focus subtitles (full screen)") }
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(onClick = {
                                if (!Settings.canDrawOverlays(context)) {
                                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                                    message = "Allow display over other apps, then return and tap Floating subtitles again."
                                } else {
                                    prefs.edit().putFloat("subtitle_size", subtitleSize).putString("subtitle_color", subtitleColorName).apply()
                                    context.startService(Intent(context, FloatingSubtitleService::class.java))
                                    message = "Floating subtitles opened. Drag the top bar to move; drag the lower-right corner to resize."
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Open floating subtitles") }
                            Spacer(Modifier.height(8.dp))
                            Text("Subtitle size: ${subtitleSize.toInt()} sp", style = MaterialTheme.typography.labelLarge)
                            Slider(value = subtitleSize, onValueChange = { subtitleSize = it; prefs.edit().putFloat("subtitle_size", it).apply() }, valueRange = 20f..80f)
                            Text("Subtitle color", style = MaterialTheme.typography.labelLarge)
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                subtitleColors.forEach { (name, color) ->
                                    FilterChip(selected = subtitleColorName == name, onClick = { subtitleColorName = name; prefs.edit().putString("subtitle_color", name).apply() },
                                        label = { Text(name, color = color) })
                                }
                            }
                        }
                    }
                }
                item {
                    Card(onClick = { orderExpanded = !orderExpanded }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("Generated order & playback details", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                Text(if (orderExpanded) "▲" else "▼")
                            }
                            if (orderExpanded) {
                                Spacer(Modifier.height(8.dp))
                                Text(message, style = MaterialTheme.typography.bodySmall)
                                Text("Generated order (${queueNames.size} tracks)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                if (queueNames.isEmpty()) Text("No generated order yet.", style = MaterialTheme.typography.bodySmall)
                                queueNames.forEach { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
                                Spacer(Modifier.height(12.dp))
                                HorizontalDivider()
                                Spacer(Modifier.height(8.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Total playlist duration", fontWeight = FontWeight.Bold)
                                    Text(totalDurationText, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun calculateQueueDuration(context: android.content.Context, entries: List<QueueEntry>): Long {
    var total = 0L
    var complete = true
    entries.forEach { entry ->
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(entry.file.uri))
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (duration == null || duration <= 0L) complete = false else total += duration
        } catch (_: Exception) {
            complete = false
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }
    return if (complete) total else -1L
}

private fun formatDuration(milliseconds: Long): String {
    val seconds = milliseconds / 1000L
    val hours = seconds / 3600L
    val minutes = (seconds % 3600L) / 60L
    val remainingSeconds = seconds % 60L
    return if (hours > 0L) String.format(java.util.Locale.getDefault(), "%d:%02d:%02d", hours, minutes, remainingSeconds)
    else String.format(java.util.Locale.getDefault(), "%d:%02d", minutes, remainingSeconds)
}

private fun generateQueue(
    all: List<AudioFile>,
    weights: Map<String, Int>,
    looping: Map<String, Boolean> = defaultLooping(),
    minLength: Int = 4,
    maxLength: Int = 48,
    surpriseB: Boolean = false,
    bFallbackMode: Boolean = false
): List<QueueEntry> {
    require(minLength in 4..999 && maxLength in 4..999 && minLength <= maxLength) {
        "Playlist length limits must be between 4 and 999, with minimum no greater than maximum."
    }
    val pools = listOf("A", "B", "X", "Y").associateWith { cat -> all.filter { it.category == cat } }
    require(all.count { it.category == "Starter" } == 1) { "Add exactly one Starter file." }
    require(pools["A"].orEmpty().isNotEmpty() && pools["Y"].orEmpty().isNotEmpty() && all.any { it.category == "Z" }) {
        "Add at least one A, Y and Z file."
    }

    val used = mutableMapOf<String, MutableSet<String>>()
    val previousLast = mutableMapOf<String, String>()
    val result = mutableListOf<QueueEntry>()
    result += QueueEntry(all.single { it.category == "Starter" }, "Starter")
    var previousCategory = "Starter"
    var hasPlayedA = false
    var aSinceLastB = 0
    // X gives Y a small one-decision weight boost. If another category is
    // selected immediately after X, the boost expires.
    var yBoostAfterX = false
    // A B must be followed by A then another B. After that second B, an A
    // is required before X or Y may become eligible.
    var mustPlayAnotherB = false
    var mustPlayAAfterBPair = false
    var guard = 0

    fun remainingSlots() = maxLength - result.size
    fun canDraw(cat: String): Boolean {
        val pool = pools[cat].orEmpty()
        if (pool.isEmpty()) return false
        val played = used[cat].orEmpty()
        return played.size < pool.size || looping[cat] != false
    }
    fun draw(cat: String): AudioFile {
        val pool = pools[cat].orEmpty()
        require(pool.isNotEmpty()) { "Category $cat has no files." }
        var played = used.getOrPut(cat) { mutableSetOf() }
        if (played.size == pool.size) {
            require(looping[cat] != false) { "Category $cat has looping turned off and all its files have already played." }
            played = mutableSetOf<String>().also { used[cat] = it }
        }
        val available = pool.filter { it.id !in played }.toMutableList()
        available.shuffle()
        val last = previousLast[cat]
        if (available.size > 1 && available.first().id == last) {
            val swap = available.indexOfFirst { it.id != last }
            val temp = available[0]; available[0] = available[swap]; available[swap] = temp
        }
        val chosen = available.first()
        played.add(chosen.id)
        previousLast[cat] = chosen.id
        return chosen
    }
    fun finishWithY() {
        require(remainingSlots() >= 2) { "The maximum length leaves no room for the required Y → Z ending. Increase the maximum." }
        result += QueueEntry(draw("Y"), "Y")
        result += QueueEntry(all.filter { it.category == "Z" }.random(), "Z")
    }

    while (true) {
        guard++
        require(guard < 10000) { "Unable to generate a valid sequence. Try increasing the maximum, enabling looping, or changing the category probabilities." }
        val slots = remainingSlots()
        val eligible = mutableListOf<String>()

        // Optional deterministic B-fallback mode. After A, X or Y may interrupt
        // the A→B rhythm; otherwise B is inserted. After X, Y gets one immediate
        // opportunity; if it is not selected, B is inserted. Every B is followed
        // by A, so neither X nor Y can follow B directly.
        if (bFallbackMode) {
            if (previousCategory == "Starter" || previousCategory == "B") {
                require(canDraw("A") && slots >= 3) { "B must be followed by A, with room left for Y → Z. Enable A looping or increase the maximum." }
                val a = draw("A")
                result += QueueEntry(a, "A")
                hasPlayedA = true
                aSinceLastB++
                previousCategory = "A"
                yBoostAfterX = false
                continue
            }

            val afterX = previousCategory == "X"
            val canChooseY = hasPlayedA && canDraw("Y") && slots >= 2 && result.size + 2 >= minLength
            val canChooseX = !afterX && hasPlayedA && previousCategory == "A" && canDraw("X") && slots >= 3 && (canDraw("B") && slots >= 5 || ((weights["Y"] ?: 0) > 0 && canDraw("Y"))) && result.size + 3 >= minLength
            val candidates = mutableListOf<Pair<String, Double>>()
            if (canChooseX) candidates += "X" to (weights["X"] ?: 0).coerceAtLeast(0).toDouble()
            if (canChooseY) candidates += "Y" to ((weights["Y"] ?: 0).coerceAtLeast(0).toDouble() * if (yBoostAfterX) 1.10 else 1.0)

            // The fallback bucket represents the ordinary A/B/X weight mass.
            // It resolves to B, ensuring B is not merely another probabilistic
            // category when neither X nor Y wins the decision.
            val fallbackMass = if (afterX) {
                ((weights["A"] ?: 0).coerceAtLeast(0) + (weights["B"] ?: 0).coerceAtLeast(0) + (weights["X"] ?: 0).coerceAtLeast(0)).toDouble()
            } else {
                ((weights["A"] ?: 0).coerceAtLeast(0) + (weights["B"] ?: 0).coerceAtLeast(0)).toDouble()
            }
            if (canDraw("B") && slots >= 4) candidates += "B" to fallbackMass.coerceAtLeast(1.0)
            val usable = candidates.filter { it.second > 0.0 }
            require(usable.isNotEmpty()) { "No valid next category can be selected. Check your files, looping settings, and maximum playlist length." }
            val total = usable.sumOf { it.second }
            var roll = Random.nextDouble(total)
            var selected = usable.last().first
            for ((cat, weight) in usable) { if (roll < weight) { selected = cat; break }; roll -= weight }
            if (selected == "B") {
                result += QueueEntry(draw("B"), "B")
                aSinceLastB = 0
                previousCategory = "B"
                yBoostAfterX = false
                continue
            }
            result += QueueEntry(draw(selected), selected)
            if (selected == "Y") {
                result += QueueEntry(all.filter { it.category == "Z" }.random(), "Z")
                break
            }
            if (selected == "A") { hasPlayedA = true; aSinceLastB++ }
            yBoostAfterX = selected == "X"
            previousCategory = selected
            continue
        }

        // A must always leave enough room for a valid Y → Z ending.
        val slotsNeededForA = when {
            mustPlayAnotherB -> 5 // A → B → A → Y → Z
            mustPlayAAfterBPair -> 3 // A → Y → Z
            else -> 3 // A → Y → Z
        }
        if (canDraw("A") && slots >= slotsNeededForA) eligible += "A"

        if (previousCategory == "A" && canDraw("B")) {
            val enoughForB = if (mustPlayAnotherB) {
                slots >= 4 // B → A → Y → Z
            } else {
                !mustPlayAAfterBPair && canDraw("A") && slots >= 6 // B → A → B → A → Y → Z
            }
            if (enoughForB) eligible += "B"
        }

        // Y is the normal stopping choice as soon as the minimum length can be met.
        // Its configured weight therefore directly controls how likely a short playlist is.
        val canEndNow = hasPlayedA && !mustPlayAnotherB && !mustPlayAAfterBPair &&
            result.size + 2 >= minLength && slots >= 2 && canDraw("Y")
        if (canEndNow) eligible += "Y"

        // X can repeat, but never immediately after B or another X.
        // Because B itself can only follow A, requiring the previous category
        // not to be B/X guarantees at least one A between successive X tracks.
        // X leaves room for a possible Y → Z ending; Y is not forced and only
        // receives its existing one-decision ×1.1 weight boost after X.
        if (hasPlayedA && previousCategory != "B" && previousCategory != "X" &&
            !mustPlayAnotherB && !mustPlayAAfterBPair &&
            result.size + 3 >= minLength && slots >= 3 && canDraw("X") && canDraw("Y")) {
            eligible += "X"
        }

        // Surprise B is a soft adaptive boost: after three A tracks since the
        // previous B, increase B's configured weight along a gentle curve.
        // It never forces B; a configured B weight of zero remains zero.
        val bMultiplier = when (aSinceLastB) {
            in 0..2 -> 1.00
            3 -> 1.15
            4 -> 1.40
            5 -> 1.80
            6 -> 2.50
            7 -> 3.80
            else -> 6.00
        }
        val weighted = eligible.map { cat ->
            val baseWeight = (weights[cat] ?: 0).coerceAtLeast(0)
            val multiplier = when {
                surpriseB && cat == "B" -> bMultiplier
                yBoostAfterX && cat == "Y" -> 1.10
                else -> 1.0
            }
            cat to (baseWeight.toDouble() * multiplier)
        }.filter { it.second > 0.0 }
        require(weighted.isNotEmpty()) {
            when {
                mustPlayAnotherB -> "The required B → A → B sequence cannot fit. Increase the maximum, enable looping, or add more A/B files."
                mustPlayAAfterBPair -> "A must play after the second B before the playlist can end. Increase the maximum or enable A looping."
                slots < 2 -> "Not enough room remains for the required Y → Z ending. Increase the maximum length."
                else -> "No eligible category has a positive probability. Adjust the category probabilities or length limits."
            }
        }

        val total = weighted.sumOf { it.second }
        var roll = Random.nextDouble(total)
        var chosenCategory = weighted.last().first
        for ((cat, weight) in weighted) {
            if (roll < weight) { chosenCategory = cat; break }
            roll -= weight
        }

        val chosen = draw(chosenCategory)
        result += QueueEntry(chosen, chosenCategory)
        when (chosenCategory) {
            "A" -> {
                hasPlayedA = true
                aSinceLastB++
                if (mustPlayAAfterBPair) mustPlayAAfterBPair = false
            }
            "B" -> {
                aSinceLastB = 0
                if (mustPlayAnotherB) {
                    mustPlayAnotherB = false
                    mustPlayAAfterBPair = true
                } else {
                    mustPlayAnotherB = true
                }
            }
            "Y" -> {
                result += QueueEntry(all.filter { it.category == "Z" }.random(), "Z")
                break
            }
            "X" -> Unit // X may recur, subject to the A-between-X and category-cycle rules.
        }
        yBoostAfterX = chosenCategory == "X"
        previousCategory = chosenCategory
    }

    require(result.size in minLength..maxLength) {
        "Generated playlist length ${result.size} is outside the selected limits."
    }
    return result
}

private fun lyricAt(subtitleText: String, positionMs: Long): String {
    if (subtitleText.isBlank()) return ""

    // LRC: [mm:ss.xx]lyric. Keep the active line visible until the next timestamp.
    val lrcPattern = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\](.*)")
    val lrcEntries = lrcPattern.findAll(subtitleText).mapNotNull { m ->
        val min = m.groupValues[1].toLongOrNull() ?: return@mapNotNull null
        val sec = m.groupValues[2].toLongOrNull() ?: return@mapNotNull null
        val fracRaw = m.groupValues[3]
        val frac = when (fracRaw.length) {
            1 -> fracRaw.toLong() * 100
            2 -> fracRaw.toLong() * 10
            3 -> fracRaw.toLong()
            else -> 0L
        }
        (min * 60000 + sec * 1000 + frac) to m.groupValues[4].trim()
    }.sortedBy { it.first }.toList()
    if (lrcEntries.isNotEmpty()) return lrcEntries.lastOrNull { it.first <= positionMs }?.second ?: ""

    // SRT: numbered cue blocks with HH:MM:SS,mmm --> HH:MM:SS,mmm timestamps.
    val timestamp = Regex("(\\d{2,}):(\\d{2}):(\\d{2})[,.](\\d{1,3})")
    fun toMillis(value: String): Long? {
        val match = timestamp.find(value) ?: return null
        val h = match.groupValues[1].toLongOrNull() ?: return null
        val m = match.groupValues[2].toLongOrNull() ?: return null
        val sec = match.groupValues[3].toLongOrNull() ?: return null
        val rawMs = match.groupValues[4]
        val ms = rawMs.padEnd(3, '0').take(3).toLongOrNull() ?: 0L
        return h * 3600000 + m * 60000 + sec * 1000 + ms
    }
    data class Cue(val start: Long, val end: Long, val text: String)
    val cues = subtitleText.replace("\r", "").trim().split(Regex("\\n\\s*\\n")).mapNotNull { block ->
        val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val timeLineIndex = lines.indexOfFirst { it.contains("-->") }
        if (timeLineIndex < 0) return@mapNotNull null
        val times = lines[timeLineIndex].split("-->", limit = 2)
        if (times.size != 2) return@mapNotNull null
        val start = toMillis(times[0]) ?: return@mapNotNull null
        val end = toMillis(times[1]) ?: return@mapNotNull null
        val text = lines.drop(timeLineIndex + 1).joinToString(" ")
            .replace(Regex("</?[^>]+>"), "").trim()
        if (text.isEmpty() || end < start) null else Cue(start, end, text)
    }.sortedBy { it.start }

    // Unlike LRC, SRT cues disappear after their specified end time.
    return cues.firstOrNull { positionMs >= it.start && positionMs <= it.end }?.text ?: ""
}

private fun displayName(context: android.content.Context, uri: Uri): String {
    var name = uri.lastPathSegment ?: "Audio"
    context.contentResolver.query(uri, null, null, null, null)?.use { c -> val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name }
    return name
}

private fun saveFiles(files: List<AudioFile>): String = JSONArray().apply { files.forEach { f -> put(JSONObject().put("id", f.id).put("name", f.name).put("uri", f.uri).put("category", f.category).put("lrc", f.lrc)) } }.toString()
private fun loadFiles(json: String): List<AudioFile> = try { val arr = JSONArray(json); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); AudioFile(o.getString("id"), o.getString("name"), o.getString("uri"), o.getString("category"), if (o.isNull("lrc")) null else o.getString("lrc")) } } catch (_: Exception) { emptyList() }

private fun savePlaylists(playlists: Map<String, PlaylistData>): String = JSONObject().apply {
    playlists.forEach { (name, data) -> put(name, JSONObject().put("files", saveFiles(data.files)).put("probabilities", JSONObject(data.probabilities)).put("looping", JSONObject(data.looping)).put("minLength", data.minLength).put("maxLength", data.maxLength).put("surpriseB", data.surpriseB).put("bFallbackMode", data.bFallbackMode)) }
}.toString()
private fun loadPlaylists(json: String): Map<String, PlaylistData> = try {
    if (json.isBlank()) emptyMap() else {
        val root = JSONObject(json); buildMap {
            val keys = root.keys(); while (keys.hasNext()) { val name = keys.next(); val item = root.getJSONObject(name); val p = item.optJSONObject("probabilities") ?: JSONObject(); val l = item.optJSONObject("looping") ?: JSONObject(); put(name, PlaylistData(loadFiles(item.optString("files", "[]")), mapOf("A" to p.optString("A", "65"), "B" to p.optString("B", "5"), "X" to p.optString("X", "5"), "Y" to p.optString("Y", "25")), mapOf("A" to l.optBoolean("A", true), "B" to l.optBoolean("B", true), "X" to l.optBoolean("X", true), "Y" to l.optBoolean("Y", true)), item.optInt("minLength", 4), item.optInt("maxLength", 48), item.optBoolean("surpriseB", false), item.optBoolean("bFallbackMode", false))) }
        }
    }
} catch (_: Exception) { emptyMap() }

private fun defaultLooping(): Map<String, Boolean> = mapOf("A" to true, "B" to true, "X" to true, "Y" to true)
