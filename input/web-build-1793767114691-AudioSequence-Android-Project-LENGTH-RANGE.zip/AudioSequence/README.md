# Audio Sequence – Android project

Version 0.5.0 adds configurable playlist length limits.

## Playlist length range
- Each playlist stores its own minimum and maximum track count.
- Defaults for existing and new playlists: minimum 4, maximum 48.
- Every generation randomly chooses a target length within the configured inclusive range.
- The generated sequence ends only with the required Y → Z ending (or X → Y → Z).
- The actual sequence may exceed the randomly selected target when a forced sequence is required, but it must remain within the configured minimum and maximum.
- Track count includes Starter and the final Z.
- Allowed values: 4–999; minimum must be less than or equal to maximum.

The project retains the previous playlist management, category probabilities, looping controls, and playback rules.

## Build
Open the project in Android Studio or use AndroidForge. Build the `debug` variant to produce an installable test APK.
