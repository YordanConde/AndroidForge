# Audio Sequence – Android project

Version 0.9.0 updates X sequencing.

## X sequencing
- X can repeat within a generated playlist, subject to its category looping setting and file-cycle rules.
- X can never play immediately after B. The existing B → A → B → A gating sequence must be completed before X or Y can become eligible.
- X can never play immediately after another X. At least one A must occur between X tracks.
- X remains a continuation category; it does not force Y.
- Immediately after an X selection, Y receives a one-time ×1.1 multiplier to its configured selection weight at the next category decision. If Y is not selected at that decision, the boost expires.
- Selecting Y still ends the sequence immediately with Z.

## Probability and playlist length behavior
- Each playlist stores its own minimum and maximum track count (defaults: 4 and 48).
- Category probabilities are applied at each eligible selection; ineligible categories are excluded and remaining weights are normalized.
- Y is a weighted ending choice once the minimum length can be met. A higher Y weight makes shorter playlists more likely.
- The maximum is a hard upper bound. Track count includes Starter and final Z.

## B sequencing and Surprise B
- B can only follow A, and B tracks cannot be consecutive. The existing B/A gating rules remain enforced before X or Y can follow.
- Optional Surprise B mode gently increases B's weight after 3 or more A tracks since the previous B: ×1.00 for 0–2; ×1.15 at 3; ×1.40 at 4; ×1.80 at 5; ×2.50 at 6; ×3.80 at 7; ×6.00 at 8+. It never guarantees B.

## Other features
The project retains multiple playlists, playlist rename/delete, category looping controls, audio playback, and synchronized LRC and SRT subtitle functionality.

## Build
Open the project in Android Studio or use AndroidForge. Build the `debug` variant to produce an installable test APK.


## Recent UI updates
- No custom launcher icon is bundled; Android uses its default app icon behavior.
- The generated playback-order panel now shows the total duration at its bottom when expanded; the duration is not shown on the main screen while the panel is collapsed. It is calculated from the durations readable from the selected audio files.

## Subtitle formats
- Attach either `.srt` SubRip subtitles or `.lrc` synchronized lyrics to an audio file using the SRT/LRC button.
- SRT cues are displayed only between their start and end timestamps; LRC lines remain active from their timestamp until the next line.
